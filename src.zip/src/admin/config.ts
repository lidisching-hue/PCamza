// Aquí pones TU correo y los de tu equipo de confianza
export const ADMIN_EMAILS = [
  'lidis@gmail.com', 
  'admin@pcamza.com',
  'sebas@gmail.com',
  // Agrega aquí cualquier otro correo que deba tener acceso total
];